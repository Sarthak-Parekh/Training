# Mailing-Application-with-Google-OAuth2

## Technologies 👇

1. Yarn
2. Node JS
3. Express JS
4. Nodemailer
5. googleapis
6. Multer

## Home Page 👇

![image](https://user-images.githubusercontent.com/58919619/122074589-3ed6a980-cdf1-11eb-9c68-8af80ede4e2f.png)

## Success Page 👇

![image](https://user-images.githubusercontent.com/58919619/122075363-ed7aea00-cdf1-11eb-82e3-d797f6986ee4.png)
